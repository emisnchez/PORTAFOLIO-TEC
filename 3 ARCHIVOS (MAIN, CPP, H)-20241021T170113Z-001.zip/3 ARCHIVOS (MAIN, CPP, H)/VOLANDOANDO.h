
#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

class USUARIO
{
private:
    string usuario;
    string contraseña;

public:
    USUARIO();
    ~USUARIO();

    void abrirMenu(int opcion);
    void ingresar();
    void registrar();
};

class DESTINOSVUELOS
{
private:
    string destino;

public:
    DESTINOSVUELOS();
    ~DESTINOSVUELOS();

    void buscarDestinos();
    string getDestino() { return destino; }
};

class LISTAESPERA
{
public:
    LISTAESPERA();
    ~LISTAESPERA();

    void listaespera();
};

class SELECCIONASIENTOS
{
private:
    vector<int> asientosdisp;
    string nombrecomp;

public:
    SELECCIONASIENTOS();
    ~SELECCIONASIENTOS();

    void mostrarAsientosDisponibles();
    bool seleccionarAsiento();
    string getnombrereserva() { return nombrecomp; }
    void setnombrereserva(string n_nomresv) { nombrecomp = n_nomresv; }
    void mostrarDatosReservacion();
    void cancelarReserva(int numAsiento);
};

class MENUFINAL
{
private:
    int salir;

public:
    MENUFINAL();
    ~MENUFINAL();

    void salirmenu();
    void cancelarvuelo(vector<int> &asientosdisp);
};
